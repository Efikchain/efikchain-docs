#!/usr/bin/env bash
# Deploy the EfikChain website on the VPS and back it up to GitHub.
# Usage: bash deploy.sh [webroot]      (default webroot: /var/www/efikcoin)
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
WEBROOT="${1:-/var/www/efikcoin}"
REPO="$HOME/efikchain-docs"

echo "1) Publishing to $WEBROOT"
sudo mkdir -p "$WEBROOT"
sudo cp "$SRC/index.html" "$WEBROOT/index.html"
sudo nginx -t && sudo systemctl reload nginx

echo "2) Backing up to GitHub"
[ -d "$REPO/.git" ] || git clone git@github.com:Efikchain/efikchain-docs.git "$REPO"
cd "$REPO"
git pull --rebase
mkdir -p website
cp "$SRC/index.html" "$SRC/deploy.sh" website/
git add website
git commit -m "Update EfikChain website" || echo "Nothing new to commit"
git push
echo "Done."
